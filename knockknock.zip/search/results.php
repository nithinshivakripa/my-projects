<!DOCTYPE html>
<html>
<head>

<title>Knock Knock Go Christian Search Engine to find Music, Images and News</title>

<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="Christian Search Engine is the best engine for Theology, Bible Study, Christian music, Online Sermons, Christian Images, Christian Books, Christian Movies, Christian News"/>
<meta name="generator" content="concrete5 - 8.2.1"/>



    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet" />
    <link href="css/main.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/jquery.typeahead.css">
    <script src="https://code.jquery.com/jquery-2.1.0.min.js"></script>
    <script src="js/jquery.typeahead.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
    <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  </head>

  <body onload= "openCity(event, 'web')">
    <div class="ccm-page page-type-page page-template-full">
      <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div class="s003 headertop" style="">

                  <form action="inner.php" method="GET">
                    <center>
                      <a href="home.php"><img src="images/knockknockgo.png" alt="KnockKnockGo" width="600" height="180" class="ccm-image-block img-responsive bID-165" title="KnockKnockGo"></a>

                    </center>
                  <div class="typeahead__container inner-form">
                    <div class="typeahead__field">
                      <div class="input-field second-wrap typeahead__query">
                        <input id="search-box" name="q" autocomplete="off" class="js-typeahead-country_v2" type="text" value="<?php echo $_GET['q']; ?>" placeholder="search..."/>
                      </div>
                    <div class="input-field third-wrap ">
                      <button class="btn-search" type="submit">
                        <svg class="svg-inline--fa fa-search fa-w-16" aria-hidden="true" data-prefix="fas" data-icon="search" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                          <path fill="currentColor" d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"></path>
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
<br><br>
        <center>
            <p style=""><strong>


    <p><a href="http://knockknockgo.com/index.php/about"><strong>Christian Search Engine</strong></a></p>

           <!-- Christian Search Engine-->

           </strong></p>
        </center>

      </form>
      <br>

    </div>

  </div>
  </div>



        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 text-center" style="margin-top:2%;">

               <div class="tab">
              <button class="tablinks" onclick="openCity(event, 'web')">WEB</button>
              <button class="tablinks" onclick="openCity(event, 'news')">NEWS</button>
              <button class="tablinks" onclick="openCity(event, 'image')">IMAGES</button>
              </div>

            </div>
        </div>
        <div class="row">
          <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 text-center" style="margin-top:2%;">
                <div id="web" class="tabcontent">
                <?php
                $search=$_GET['q'];
                $apikey='2703019112085548571';
                $str = file_get_contents('https://contextualwebsearch.com/api/Search/CustomWebSearchAPI?apiKey=2703019112085548571&q='.$search.'&pagenumber=1&pageSize=10&&autoCorrect=true&safeSearch=false');
                $json = json_decode($str, true);


                foreach($json['value'] as $item)
                {

                  echo '<h3>'.$item['title'].'</h3>';
                  echo '<a href="'.$item['url'].'">'.$item['url'].'</a></br>';
                  echo '<p>'.$item['description'].'</p></br>';

                }


                ?>
              </div>
              <div id="news" class="tabcontent">
                <?php
                $search=$_GET['q'];
                $apikey='2703019112085548571';
                $str = file_get_contents('https://contextualwebsearch.com/api/Search/CustomNewsSearchAPI?apiKey=2703019112085548571&q='.$search.'&pagenumber=1&pageSize=10&&autoCorrect=true&safeSearch=false');
                $json = json_decode($str, true);


                foreach($json['value'] as $item)
                {

                  echo '<h3>'.$item['title'].'</h3>';
                  echo '<a href="'.$item['url'].'">'.$item['url'].'</a></br>';
                  echo '<p>'.$item['description'].'</p></br>';

                }


                //echo '<pre>' . print_r($json, true) . '</pre>';
                ?>
              </div>
              <div id="image" class="tabcontent">
                <?php
                $search=$_GET['q'];
                $apikey='2703019112085548571';
                $str = file_get_contents('https://contextualwebsearch.com/api/Search/CustomImageSearchAPI?apiKey=2703019112085548571&q='.$search.'&pagenumber=1&pageSize=10&autoCorrect=true&safeSearch=true');
                $json = json_decode($str, true);
                $numOfCols = 4;
                $rowCount = 0;
                $bootstrapColWidth = 12 / $numOfCols;
                // echo $search;
              ?>  <div class="row">

                <?php
                foreach($json['value'] as $item)
                {
                ?>
                <div class="col-md-<?php echo $bootstrapColWidth; ?>">
                  <div class="thumbnail">
                    <?php

                      echo '<img src="'.$item['url'].'"></br>';
                      ?>
                    </div>
                  </div>
                  <?php
                      $rowCount++;
                          if($rowCount % $numOfCols == 0) echo '</div><div class="row">';
                      }

                      ?>
              </div>
            </div>
          </div>
        </div>


         <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <footer class="footer" style="margin-top:6%;">
                        <div class="container text-center">


                            <p>&nbsp;</p>

                            <center>Supported By <a href="https://contextualweb.io" target="_blank">Contextualweb</a></center>

                            <p>&nbsp;</p>

                            <p><span class="copyright">&copy; 2018 - Knockknockgo.com</span> &nbsp;&nbsp;&nbsp; <a href="http://knockknockgo.com/index.php/faq">FAQ</a>&nbsp;| <a href="http://knockknockgo.com/index.php/privacypolicy">Privacy Policy</a> | <a href="http://knockknockgo.com/index.php/about">About</a> | <a href="http://knockknockgo.com/index.php/contact">Contact</a></p>

                        </div>
                </footer>
            </div>
          </div>
        </div>
      </div>
      <script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>
<script>
function myfunction(){
  alert("hiiii");
}
</script>

  </body>
</html>
