﻿$(".typeahead").autocomplete({
    source: function (request, callback) {
        var safeSearch = (window.isSafeSearch === true || window.getUrlParam('safe') === '1') ? '1' : '0';
        $.getJSON("/search/suggest", { eq: encQuery(request.term), safe: safeSearch }, function (data) {
            //console.log(data);
            callback(data);
        });
    },
    select: function (event, ui) {
        var destinationPage = $('#destination_page').length > 0 ? $('#destination_page').val() : null;
        var _int = document.querySelector('input[name="int"]');
        window.location = '/encsearch?q=' + ui.item.value + (destinationPage ? '&d=' + destinationPage : '') +
            (_int && _int.value === 'nty' ? '&int=' + _int.value : '');
    },
    minLength: 2
});