<!DOCTYPE html>
<html>
<head>

<title>Knock Knock Go Christian Search Engine to find Music, Images and News</title>

<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="Christian Search Engine is the best engine for Theology, Bible Study, Christian music, Online Sermons, Christian Images, Christian Books, Christian Movies, Christian News"/>
<meta name="generator" content="concrete5 - 8.2.1"/>



    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet" />
    <link href="css/main.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/jquery.typeahead.css">
    <script src="https://code.jquery.com/jquery-2.1.0.min.js"></script>
    <script src="js/jquery.typeahead.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
    <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  </head>

  <body>
    <div class="ccm-page page-type-page page-template-full">
      <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 text-center" style="margin-top:2%;">



            </div>
        </div>
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div class="s003" style="">

                  <form action="websearch.php" method="GET">
                    <center>
                    <a href="home.php"><img src="images/knockknockgo.png" alt="KnockKnockGo" width="600" height="180" class="ccm-image-block img-responsive bID-165" title="KnockKnockGo"></a>
                    </center>
        <div class="typeahead__container inner-form">
          <div class="typeahead__field">
            <div class="input-field second-wrap typeahead__query">
              <input id="search-box" name="q" autocomplete="off" class="js-typeahead-country_v2" type="text" placeholder="Search....."  />
            </div>
          <div class="input-field third-wrap ">
            <button class="btn-search" type="submit">
              <svg class="svg-inline--fa fa-search fa-w-16" aria-hidden="true" data-prefix="fas" data-icon="search" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                <path fill="currentColor" d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"></path>
              </svg>
            </button>
          </div>
        </div>
      </div>
<br><br>
        <center>
            <p style=""><strong>


    <p><a href="http://knockknockgo.com/index.php/about"><strong>Christian Search Engine</strong></a></p>

           <!-- Christian Search Engine-->

           </strong></p>
        </center>

      </form>
      <br>

    </div>

  </div>
  </div>

         <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <footer class="footer" style="margin-top:6%;">
                        <div class="container text-center">


                            <p>&nbsp;</p>

                            <center>Supported By <a href="https://contextualweb.io" target="_blank">Contextualweb</a></center>

                            <p>&nbsp;</p>

                            <p><span class="copyright">&copy; 2018 - Knockknockgo.com</span> &nbsp;&nbsp;&nbsp; <a href="http://knockknockgo.com/index.php/faq">FAQ</a>&nbsp;| <a href="http://knockknockgo.com/index.php/privacypolicy">Privacy Policy</a> | <a href="http://knockknockgo.com/index.php/about">About</a> | <a href="http://knockknockgo.com/index.php/contact">Contact</a></p>

                        </div>
                </footer>
            </div>
          </div>
        </div>
      </div>
           <script>

// $.typeahead({
//     input: '.js-typeahead-country_v2',
//     minLength: 1,
//     maxItem: 20,
//     order: "asc",
//     hint: true,
//     accent: true,
//     searchOnFocus: true,
//     dynamic: true,
//     href: "results.php?q={{display}}",
//     template: "{{display}}",
    // source: {
    //     country:  {
    //         ajax: function (query) {
    //             return {
    //                 type: "GET",
    //                 url: "/application/themes/knockknockgo/autocomplete.php",
    //                 path: "body",
    //                 data: {
    //                     q: "{{query}}"
    //                 },
    //                 callback: {
    //                     done: function (data) {
    //                         return data;
    //                     }
    //                 }
    //             }
    //         }
    //     },
    //
    // },
//     callback: {
//         onNavigateAfter: function (node, lis, a, item, query, event) {
//             if (~[38,40].indexOf(event.keyCode)) {
//                 var resultList = node.closest("form").find("ul.typeahead__list"),
//                     activeLi = lis.filter("li.active"),
//                     offsetTop = activeLi[0] && activeLi[0].offsetTop - (resultList.height() / 2) || 0;
//
//                 resultList.scrollTop(offsetTop);
//             }
//
//         },
//         onClickAfter: function (node, a, item, event) {
//              event.preventDefault();
//             window.location = item.href;
//             //window.moveTo(item.href);
//             //window.open(item.href);
//
//
//            // $('#result-container').text('');
//
//         },
//         onResult: function (node, query, result, resultCount) {
//             if (query === "") return;
//
//             var text = "";
//             if (result.length > 0 && result.length < resultCount) {
//                 text = "Showing <strong>" + result.length + "</strong> of <strong>" + resultCount + '</strong> elements matching "' + query + '"';
//             } else if (result.length > 0) {
//                 text = 'Showing <strong>' + result.length + '</strong> elements matching "' + query + '"';
//             } else {
//                 text = 'No results matching "' + query + '"';
//             }
//             //$('#result-container').html(text);
//
//         },
//         onMouseEnter: function (node, a, item, event) {
//
//             if (item.group === "country") {
//                 $(a).append('<span class="flag-chart flag-' + item.display.replace(' ', '-').toLowerCase() + '"></span>')
//             }
//
//         },
//         onMouseLeave: function (node, a, item, event) {
//
//             $(a).find('.flag-chart').remove();
//
//         }
//     }
// });

    </script>
  </body>
</html>
